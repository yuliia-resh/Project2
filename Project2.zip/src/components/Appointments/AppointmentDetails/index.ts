export { default } from "./AppointmentDetails";
