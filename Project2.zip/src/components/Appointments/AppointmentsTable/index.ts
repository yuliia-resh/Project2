export { default } from "./AppointmentsTable";
